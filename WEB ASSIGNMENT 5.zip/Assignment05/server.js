
const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const PORT = process.env.PORT || 8080;

let projects = [
    { id: 1, name: 'Solar Panels', sector: 'Energy', summary: 'Clean energy from the sun' },
    { id: 2, name: 'Reforestation', sector: 'Land Use', summary: 'Planting trees to absorb CO2' }
];

// Middleware
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
app.get('/', (req, res) => res.render('home'));

app.get('/solutions/projects', (req, res) => res.render('projects', { projects }));

app.get('/solutions/projects/add', (req, res) => res.render('add'));
app.post('/solutions/projects/add', (req, res) => {
    const { name, sector, summary } = req.body;
    const newProject = { id: Date.now(), name, sector, summary };
    projects.push(newProject);
    res.redirect('/solutions/projects');
});

app.get('/solutions/projects/edit/:id', (req, res) => {
    const project = projects.find(p => p.id == req.params.id);
    res.render('edit', { project });
});
app.post('/solutions/projects/edit/:id', (req, res) => {
    const { name, sector, summary } = req.body;
    const project = projects.find(p => p.id == req.params.id);
    if (project) {
        project.name = name;
        project.sector = sector;
        project.summary = summary;
    }
    res.redirect('/solutions/projects');
});

app.get('/solutions/projects/delete/:id', (req, res) => {
    projects = projects.filter(p => p.id != req.params.id);
    res.redirect('/solutions/projects');
});

app.use((req, res) => res.status(404).render('404'));
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
